Impulse drive works with any model or ship you might have

How to install ImpulseDrive:

- open the config file of your part
- add this 

////////// Impulse ///////////////
    MODULE
    {
        name = LCARS_ImpulseDrive
        RESOURCE
        {
            name = ElectricCharge
            rate = 0.1
        }
    }
////////// Impulse ///////////////

- done

One such part per vessel is enough.
If you add more of these parts, it might produce some lag.


For subsystems, add one or all of the following to a fitting part:

///////////////////////////////
    MODULE
    {
        name = LCARS_ShuttleBay
        volume = 450
    }
    MODULE
    {
        name = LCARS_CargoBay
        maxTonnage = 200
    }
    MODULE
    {
        name = LCARS_CloakingDevice
    }
    MODULE
    {
        name = LCARS_StructuralIntegrityField
    }
    MODULE
    {
        name = LCARS_FuelTransfer
    }
    MODULE
    {
        name = LCARS_CrewQuartier
    }
    MODULE
    {
        name = LCARS_TransporterSystem
    }
    MODULE
    {
        name = LCARS_WeaponSystems
    }
    MODULE
    {
        name = LCARS_PhotonTorpedo
    }
    MODULE
    {
        name = LCARS_TractorBeam
    }

///////////////////////////////